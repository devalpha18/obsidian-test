import Container from "@mui/material/Container";

export default function Vault() {

  return (
    <Container sx={{ py: 8 }} maxWidth="lg">
      123
    </Container>
  );
}